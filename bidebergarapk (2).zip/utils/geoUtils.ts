
import { Waypoint, PKResult } from '../types';

/**
 * Calcula la distancia Haversine en metros.
 */
export const getDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
  const R = 6371e3;
  const phi1 = (lat1 * Math.PI) / 180;
  const phi2 = (lat2 * Math.PI) / 180;
  const deltaPhi = ((lat2 - lat1) * Math.PI) / 180;
  const deltaLambda = ((lon2 - lon1) * Math.PI) / 180;

  const a =
    Math.sin(deltaPhi / 2) * Math.sin(deltaPhi / 2) +
    Math.cos(phi1) * Math.cos(phi2) * Math.sin(deltaLambda / 2) * Math.sin(deltaLambda / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c;
};

/**
 * Proyecta un punto sobre el segmento de carretera más cercano.
 */
export const projectToRoad = (userLat: number, userLng: number, waypoints: Waypoint[]): { pk: number, lat: number, lng: number, distance: number } => {
  let minDistance = Infinity;
  let bestPK = 0;
  let bestLat = userLat;
  let bestLng = userLng;

  if (waypoints.length < 2) return { pk: 0, lat: userLat, lng: userLng, distance: 9999 };

  // Factor de corrección para la longitud según la latitud (aproximado para el tramo)
  const cosLat = Math.cos((userLat * Math.PI) / 180);

  for (let i = 0; i < waypoints.length - 1; i++) {
    const p1 = waypoints[i];
    const p2 = waypoints[i + 1];

    // Usamos distancias relativas ajustadas
    const dx = (p2.lng - p1.lng) * cosLat;
    const dy = p2.lat - p1.lat;
    const dux = (userLng - p1.lng) * cosLat;
    const duy = userLat - p1.lat;
    
    if (dx === 0 && dy === 0) continue;

    let t = (dux * dx + duy * dy) / (dx * dx + dy * dy);
    t = Math.max(0, Math.min(1, t)); 

    const projLat = p1.lat + t * (p2.lat - p1.lat);
    const projLng = p1.lng + t * (p2.lng - p1.lng);
    
    const currentPK = p1.pk + t * (p2.pk - p1.pk);
    const dist = getDistance(userLat, userLng, projLat, projLng);

    if (dist < minDistance) {
      minDistance = dist;
      bestPK = currentPK;
      bestLat = projLat;
      bestLng = projLng;
    }
  }

  return { pk: bestPK, lat: bestLat, lng: bestLng, distance: minDistance };
};

export const calculatePK = (userLat: number, userLng: number, accuracy: number, waypoints: Waypoint[]): PKResult => {
  const projection = projectToRoad(userLat, userLng, waypoints);

  return {
    pk: projection.pk,
    accuracy: accuracy,
    timestamp: Date.now(),
    lat: projection.lat, 
    lng: projection.lng,
    distanceToRoad: projection.distance
  };
};

export const getCoordsFromPK = (targetPK: number, waypoints: Waypoint[]): { lat: number, lng: number } | null => {
  if (waypoints.length < 2) return null;
  const sorted = [...waypoints].sort((a, b) => a.pk - b.pk);
  if (targetPK < sorted[0].pk || targetPK > sorted[sorted.length - 1].pk) return null;

  for (let i = 0; i < sorted.length - 1; i++) {
    const p1 = sorted[i];
    const p2 = sorted[i+1];
    if (targetPK >= p1.pk && targetPK <= p2.pk) {
      const ratio = (targetPK - p1.pk) / (p2.pk - p1.pk);
      return {
        lat: p1.lat + ratio * (p2.lat - p1.lat),
        lng: p1.lng + ratio * (p2.lng - p1.lng)
      };
    }
  }
  return null;
};
