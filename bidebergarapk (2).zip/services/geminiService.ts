
import { GoogleGenAI } from "@google/genai";

export const getLocationContext = async (lat: number, lng: number, pk: number, roadName: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-1.5-flash',
      contents: `El usuario se encuentra en la vía ${roadName}, en el PK ${pk.toFixed(3)} (Coordenadas: ${lat}, ${lng}). 
      Proporciona una breve descripción del entorno físico en este punto exacto (nombre del tramo, municipio, orografía o infraestructuras cercanas como túneles, viaductos o áreas de servicio). 
      Responde de forma muy concisa y técnica para un operario de mantenimiento en menos de 35 palabras. Evita mencionar errores de precisión GPS.`,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Localización identificada. Cargando detalles del entorno...";
  }
};

export const generateIncidentReport = async (pk: number, locationDesc: string, userNotes: string, roadName: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-1.5-flash',
      contents: `Genera un mensaje corto para informar de un incidente en la ${roadName}.
      PK: ${pk.toFixed(3)}
      Ubicación: ${locationDesc}
      Notas del operario: ${userNotes}
      
      El formato debe ser profesional y directo para un centro de control de tráfico.`,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Error al generar el reporte automático.";
  }
};
