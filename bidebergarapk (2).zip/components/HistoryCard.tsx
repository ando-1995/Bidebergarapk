
import React from 'react';
import { IncidentLog } from '../types';
import { MapPin, Clock, Trash2 } from 'lucide-react';

interface HistoryCardProps {
  logs: IncidentLog[];
  onClear: () => void;
  onRemove: (id: string) => void;
}

const HistoryCard: React.FC<HistoryCardProps> = ({ logs, onClear, onRemove }) => {
  if (logs.length === 0) return null;

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden mt-6">
      <div className="p-4 border-b border-slate-50 flex justify-between items-center bg-slate-50/50">
        <h3 className="font-semibold text-slate-800 flex items-center gap-2">
          <Clock className="w-4 h-4" /> Historial de Ubicaciones
        </h3>
        <button 
          onClick={onClear}
          className="text-xs text-red-500 font-medium hover:bg-red-50 px-2 py-1 rounded-lg transition-colors"
        >
          Limpiar Todo
        </button>
      </div>
      <div className="divide-y divide-slate-50 max-h-64 overflow-y-auto">
        {logs.map((log) => (
          <div key={log.id} className="p-4 flex items-center justify-between group hover:bg-slate-50 transition-colors">
            <div className="flex items-start gap-3">
              <div className="bg-blue-50 p-2 rounded-full">
                <MapPin className="w-4 h-4 text-blue-500" />
              </div>
              <div>
                <p className="font-bold text-slate-900">PK {log.pk}</p>
                <p className="text-xs text-slate-400">
                  {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                </p>
              </div>
            </div>
            <button 
              onClick={() => onRemove(log.id)}
              className="p-2 text-slate-300 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HistoryCard;
